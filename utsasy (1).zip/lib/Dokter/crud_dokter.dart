import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class CrudDokter extends StatefulWidget {
  final Map<String, dynamic>? dataDokter;
  const CrudDokter({Key? key, this.dataDokter}) : super(key: key);
  @override
  CrudDokterState createState() => CrudDokterState();
}

class CrudDokterState extends State<CrudDokter> {
  String status = "";
  TextEditingController idDokterController = new TextEditingController();
  TextEditingController namaDoktercontroller = new TextEditingController();
  TextEditingController spesialisasiController = new TextEditingController();
  TextEditingController noTelpController = new TextEditingController();
  TextEditingController alamatController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.dataDokter != null) {
      status = "Edit Data dokter";
      idDokterController.text = widget.dataDokter?['id_dokter'] ?? '';
      namaDoktercontroller.text = widget.dataDokter?['nama_dokter'] ?? '';
      spesialisasiController.text = widget.dataDokter?['spesialisasi'] ?? '';
      noTelpController.text = widget.dataDokter?['no_telp'] ?? '';
      alamatController.text = widget.dataDokter?['alamat'] ?? '';
    } else {
      status = "Tambah Data dokter";
      // idDokterController.text = "";
      // namaDoktercontroller.text = spesialisasiController.text = "";
      // alamatController.text = "";
      // noTelpController.text = "";
      // kadaluarsaController.text = "";
    }
  }

  // Menambah Data dokter
  Future tambahDokter() async {
    return await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/dokter/create.php"),
      body: {
        "id_dokter": idDokterController.text,
        "nama_dokter": namaDoktercontroller.text,
        "spesialisasi": spesialisasiController.text,
        "no_telp": noTelpController.text,
        "alamat": alamatController.text,
      },
    );
  }

  // Update Data dokter
  Future UpdateDokter() async {
    return await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/dokter/update.php"),
      body: {
        "id_dokter": widget.dataDokter?['id_dokter'],
        "nama_dokter": namaDoktercontroller.text,
        "spesialisasi": spesialisasiController.text,
        "no_telp": noTelpController.text,
        "alamat": alamatController.text,
      },
    );
  }

  bool validasiInput() {
    if (idDokterController.text.isEmpty ||
        namaDoktercontroller.text.isEmpty ||
        spesialisasiController.text.isEmpty ||
        noTelpController.text.isEmpty ||
        alamatController.text.isEmpty) {
      tampilkanPesan("Semua Kolom Input Wajib diisi", isError: true);
      return false;
    }
    return true;
  }

  void tampilkanPesan(String pesan, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(pesan),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(status),
        ),
        body: Container(
          height: double.infinity,
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  TextFormField(
                    controller: idDokterController,
                    decoration: InputDecoration(labelText: "ID DOKTER"),
                  ),
                  TextFormField(
                    controller: namaDoktercontroller,
                    decoration: InputDecoration(labelText: "NAMA DOKTER"),
                  ),
                  TextFormField(
                    controller: spesialisasiController,
                    decoration:
                        InputDecoration(labelText: "SPESIALISASI DOKTER"),
                  ),
                  TextFormField(
                    controller: alamatController,
                    decoration: InputDecoration(labelText: "ALAMAT DOKTER"),
                  ),
                  TextFormField(
                    controller: noTelpController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: "NO_TELP DOKTER"),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                      onPressed: () async {
                        if (!validasiInput()) return;
                        final respon = widget.dataDokter == null
                            ? await tambahDokter()
                            : await UpdateDokter();
                        if (respon.statusCode == 200) {
                          tampilkanPesan(widget.dataDokter == null
                              ? "Data Berhasil ditambahkan"
                              : "Data Berhasil Diedit");
                          Navigator.pop(context, true);
                        } else {
                          tampilkanPesan("Gagal Menyimpan Data", isError: true);
                        }
                      },
                      child:
                          Text(widget.dataDokter == null ? "Tambah" : "Edit")),
                ],
              ),
            ),
          ),
        ));
  }
}
