import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class CrudObat extends StatefulWidget {
  final Map<String, dynamic>? dataObat;
  const CrudObat({Key? key, this.dataObat}) : super(key: key);
  @override
  CrudObatState createState() => CrudObatState();
}

class CrudObatState extends State<CrudObat> {
  String status = "";
  TextEditingController idObatController = new TextEditingController();
  TextEditingController namaController = new TextEditingController();
  TextEditingController deskripsiController = new TextEditingController();
  TextEditingController stokController = new TextEditingController();
  TextEditingController hargaController = new TextEditingController();
  TextEditingController kadaluarsaController = new TextEditingController();

  final dateFormat = DateFormat('yyyy-MM-dd');
  @override
  void initState() {
    super.initState();
    if (widget.dataObat != null) {
      status = "Edit Data Obat";
      idObatController.text = widget.dataObat?['id_obat'] ?? '';
      namaController.text = widget.dataObat?['nama'] ?? '';
      deskripsiController.text = widget.dataObat?['deskripsi'] ?? '';
      hargaController.text = widget.dataObat?['harga'].toString() ?? '';
      stokController.text = widget.dataObat?['stok'].toString() ?? '';
      kadaluarsaController.text = widget.dataObat?['kadaluarsa'] ?? '';
    } else {
      status = "Tambah Data Obat";
      // idObatController.text = "";
      // namaController.text = deskripsiController.text = "";
      // hargaController.text = "";
      // stokController.text = "";
      // kadaluarsaController.text = "";
    }
  }

  // Menambah Data Obat
  Future tambahObat() async {
    return await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/obat/create.php"),
      body: {
        "id_obat": idObatController.text,
        "nama": namaController.text,
        "stok": stokController.text,
        "harga": hargaController.text,
        "deskripsi": deskripsiController.text,
        "kadaluarsa": kadaluarsaController.text,
      },
    );
  }

  // Update Data Obat
  Future UpdateObat() async {
    return await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/obat/update.php"),
      body: {
        "id_obat": widget.dataObat?['id_obat'],
        "nama": namaController.text,
        "stok": stokController.text,
        "harga": hargaController.text,
        "deskripsi": deskripsiController.text,
        "kadaluarsa": kadaluarsaController.text,
      },
    );
  }

  bool validasiInput() {
    if (idObatController.text.isEmpty ||
        namaController.text.isEmpty ||
        deskripsiController.text.isEmpty ||
        stokController.text.isEmpty ||
        hargaController.text.isEmpty ||
        kadaluarsaController.text.isEmpty) {
      tampilkanPesan("Semua Kolom Input Wajib diisi", isError: true);
      return false;
    }
    if (int.tryParse(stokController.text) == null) {
      tampilkanPesan("Stok harus berupa angka", isError: true);
      return false;
    }
    if (int.tryParse(hargaController.text) == null) {
      tampilkanPesan("Harga harus berupa angka", isError: true);
      return false;
    }
    try {
      dateFormat.parse(kadaluarsaController.text);
    } catch (_) {
      tampilkanPesan("Tanggal Kadaluarsa Tidak Valid", isError: true);
      return false;
    }
    return true;
  }

  void tampilkanPesan(String pesan, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(pesan),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  Future<void> selectDate(BuildContext context) async {
    DateTime initialDate =
        DateTime.tryParse(kadaluarsaController.text) ?? DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      kadaluarsaController.text = dateFormat.format(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(status),
        ),
        body: Container(
          height: double.infinity,
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  TextFormField(
                    controller: idObatController,
                    decoration: InputDecoration(labelText: "ID OBAT"),
                  ),
                  TextFormField(
                    controller: namaController,
                    decoration: InputDecoration(labelText: "NAMA OBAT"),
                  ),
                  TextFormField(
                    controller: deskripsiController,
                    decoration: InputDecoration(labelText: "DESKRIPSI OBAT"),
                  ),
                  TextFormField(
                    controller: stokController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: "STOK OBAT"),
                  ),
                  TextFormField(
                    controller: hargaController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: "HARGA OBAT"),
                  ),
                  TextFormField(
                    controller: kadaluarsaController,
                    readOnly: true,
                    onTap: () => selectDate(context),
                    decoration:
                        InputDecoration(labelText: "TANGGAL KADALUARSA"),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                      onPressed: () async {
                        if (!validasiInput()) return;
                        final respon = widget.dataObat == null
                            ? await tambahObat()
                            : await UpdateObat();
                        if (respon.statusCode == 200) {
                          tampilkanPesan(widget.dataObat == null
                              ? "Data Berhasil ditambahkan"
                              : "Data Berhasil Diedit");
                          Navigator.pop(context, true);
                        } else {
                          tampilkanPesan("Gagal Menyimpan Data", isError: true);
                        }
                      },
                      child: Text(widget.dataObat == null ? "Tambah" : "Edit")),
                ],
              ),
            ),
          ),
        ));
  }
}
