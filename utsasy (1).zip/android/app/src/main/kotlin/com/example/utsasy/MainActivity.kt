package com.example.utsasy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
